# Permission to Relicense under MPLv2

This is a statement by Dave Meehan
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "dmeehan1968", with
commit author "Dave Meehan dave_meehan@replicated.co.uk", are copyright of Dave Meehan.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

Dave Meehan
2019/08/31
