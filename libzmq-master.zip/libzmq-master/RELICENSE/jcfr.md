# Permission to Relicense under MPLv2

This is a statement by Jean-Christophe Fillion-Robin
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "jcfr", with
commit author "Jean-Christophe Fillion-Robin <jchris.fillionr@kitware.com>", are copyright of Kitware Inc.
This document hereby grants the libzmq project team to relicense libzmq,
including all past, present and future contributions of the author listed above.

Jean-Christophe Fillion-Robin
2019/09/03
