# Permission to Relicense under MPLv2

This is a statement by Jérémie Courrèges-Anglas
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "jcourreges", with
commit author "Jérémie Courrèges-Anglas", are copyright of Jérémie Courrèges-Anglas.
This document hereby grants the libzmq project team to relicense libzmq,
including all past, present and future contributions of the author listed above.

Jérémie Courrèges-Anglas
2018/12/07
